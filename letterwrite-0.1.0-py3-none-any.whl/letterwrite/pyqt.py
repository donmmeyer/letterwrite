import sys
import os
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QLabel, QTextEdit, QComboBox,
    QPushButton, QMessageBox, QLineEdit, QDialog, QFormLayout
)
from PyQt5.QtCore import Qt
from docx import Document
from datetime import datetime
import pandas as pd
from openai import OpenAI  # Replace with your OpenAI client initialization

# Ensure required folders exist
LOG_FOLDER = "log"
os.makedirs(LOG_FOLDER, exist_ok=True)

FORMBASE_FOLDER = "formbase"
os.makedirs(FORMBASE_FOLDER, exist_ok=True)

CONTACTS_FOLDER = "contacts"
os.makedirs(CONTACTS_FOLDER, exist_ok=True)

STYLE_GUIDE = "Example letters follow a professional tone and include clear details."

def get_available_categories():
    return [
        os.path.splitext(f)[0] for f in os.listdir(FORMBASE_FOLDER)
        if f.endswith(".docx")
    ]
    
def get_context(category):
    """Get the context for the selected category."""
    try:
        doc_path = os.path.join(FORMBASE_FOLDER, f"{category}.docx")
        if os.path.exists(doc_path):
            doc = Document(doc_path)
            category_context = "\n".join([p.text for p in doc.paragraphs])
            return f"{category_context}\n\n{STYLE_GUIDE}"
        else:
            return f"No context available for {category}.\n\n{STYLE_GUIDE}"
    except Exception as e:
        return f"Error reading context for {category}: {e}"
        
def get_unique_filename(base_name):
    """Generate a unique file name by appending letters if the file exists."""
    if not os.path.exists(base_name):
        return base_name

    base, ext = os.path.splitext(base_name)
    for letter in "abcdefghijklmnopqrstuvwxyz":
        new_name = f"{base}_{letter}{ext}"
        if not os.path.exists(new_name):
            return new_name
            
def get_contacts():
    try:
        contacts_path = os.path.join(CONTACTS_FOLDER, "contacts.xlsx")
        if not os.path.exists(contacts_path):
            return []
        df = pd.read_excel(contacts_path)
        return [
            {
                "name": row["name"],
                "address1": row["address1"],
                "address2": row["address2"],
                "city": row["city"],
                "state": row["state"],
                "zip": row["zip"]
            }
            for _, row in df.iterrows()
        ]
    except Exception as e:
        QMessageBox.critical(None, "Error", f"Failed to load contacts: {e}")
        return []



def save_new_contact(contact_info):
    try:
        contacts_path = os.path.join(CONTACTS_FOLDER, "contacts.xlsx")
        # Check if the file exists
        if os.path.exists(contacts_path):
            df = pd.read_excel(contacts_path)
        else:
            df = pd.DataFrame(columns=["name", "address1", "address2", "city", "state", "zip"])

        # Create a DataFrame for the new contact
        new_contact_df = pd.DataFrame([contact_info])
        
        # Concatenate the new contact to the existing DataFrame
        df = pd.concat([df, new_contact_df], ignore_index=True)
        
        # Save the updated DataFrame to the Excel file
        df.to_excel(contacts_path, index=False)
    except Exception as e:
        QMessageBox.critical(None, "Error", f"Failed to save contact: {e}")

def read_word_document(category):
    file_path = os.path.join(FORMBASE_FOLDER,f"{category}.docx")
    try:
        doc = Document(file_path)
        return "\n".join([para.text for para in doc.paragraphs])
    except Exception as e:
        print(f"Error reading document for {category}: {e}")
        return None


def log_response_to_docx(response, category):
    """Log the generated response to a Word document."""
    try:
        date_str = datetime.now().strftime("%Y-%m-%d")
        log_file_path = os.path.join(LOG_FOLDER, f"{date_str}_{category.replace(' ', '_')}.docx")
        log_file_path = get_unique_filename(log_file_path)  
        if os.path.exists(log_file_path):
            doc = Document(log_file_path)
        else:
            doc = Document()
    
        doc.add_paragraph(response, style="Normal")
        doc.save(log_file_path)
    except PermissionError:
        QMessageBox.warning(
            None,
            "File Open Error",
            f"Failed to log response: The file '{log_file_path}' is open. Please close the Word document and try again."
        )
    except Exception as e:
        QMessageBox.critical(None, "Error", f"Failed to log response: {e}")

def get_gpt_suggestions(text):
    # Uncomment and set this if required for your API setup
    
    try:
        client = OpenAI()  # Initialize the OpenAI client
        response = client.chat.completions.create(
            model="gpt-4o-mini",  # Use "gpt-4o-mini" if supported by your API
            messages=[
                {"role": "system", "content": "Start with the text, 'Here are suggested parameters. Edit them or add and delete as necessary. :'"},
                {"role": "user", "content": f"Based on the following text, suggest a few parameters for a legal letter. Leave out any reference to the recipient and the recipient's address or the sender and the sender's address.  Include only the essential information and no '*':\n\n{text}"}
            ],
            max_tokens=150
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"Error with GPT request: {e}")
        return "Error generating suggestions."


def ask_gpt_mini(question, category, contact_info):
    """Function to query the OpenAI GPT model with context."""
    try:
        sender_details = (
            "F. Kevin Lynch, Esq.\n"
            "Attorney at Law\n"
            "2 Auer Ct\n"
            "East Brunswick, NJ 08816\n"
            "(732) 254-1221\n"
        )
        
        today_date = datetime.now().strftime("%B %d, %Y")
        header = f"{sender_details}\n{today_date}\n"
        
        context = get_context(category)

        # Include contact information in the question
        contact_details = (
            f"Contact Name: {contact_info['name']}\n"
            f"Address1: {contact_info['address1']}\n"
            f"Address2: {contact_info['address2']}\n"
            f"City: {contact_info['city']}\n"
            f"State: {contact_info['state']}\n"
            f"Zip: {contact_info['zip']}\n"
        ) if contact_info else ""

        combined_question = f"Contact is:\n{contact_details}\n{question}" if question else f"Contact is:\n{contact_details}"
        context_with_prompt = f"Write a letter using {header}\n\n{context}"

        client = OpenAI()  # Initialize the OpenAI client
        response = client.chat.completions.create(
            model="gpt-4o-mini",  # Replace with your OpenAI model
            messages=[
                {"role": "system", "content": context_with_prompt},
                {"role": "user", "content": combined_question},
            ]
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"Error: {str(e)}"

class NewContactDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("New Contact")
        self.setGeometry(200, 200, 400, 300)
        self.contact_info = None

        layout = QFormLayout()

        self.name_input = QLineEdit()
        self.address1_input = QLineEdit()
        self.address2_input = QLineEdit()
        self.city_input = QLineEdit()
        self.state_input = QLineEdit()
        self.zip_input = QLineEdit()

        layout.addRow("Name:", self.name_input)
        layout.addRow("Address1:", self.address1_input)
        layout.addRow("Address2:", self.address2_input)
        layout.addRow("City:", self.city_input)
        layout.addRow("State:", self.state_input)
        layout.addRow("Zip:", self.zip_input)

        self.save_button = QPushButton("Save")
        self.save_button.clicked.connect(self.save_contact)
        layout.addWidget(self.save_button)

        self.setLayout(layout)

    def save_contact(self):
        self.contact_info = {
            "name": self.name_input.text().strip(),
            "address1": self.address1_input.text().strip(),
            "address2": self.address2_input.text().strip(),
            "city": self.city_input.text().strip(),
            "state": self.state_input.text().strip(),
            "zip": self.zip_input.text().strip(),
        }

        if not self.contact_info["name"]:
            QMessageBox.warning(self, "Input Error", "Name cannot be empty.")
            return

        save_new_contact(self.contact_info)
        self.accept()

class LegalLetterApp(QWidget):
    def __init__(self):
        super().__init__()
        self.contacts = get_contacts()
        self.selected_contact = None
        self.initUI()

    def show_help(self):
        """Display a help dialog with an explanation of the program."""
        help_message = (
            "This program generates legal letters based on a selected category and contact information.\n\n"
            "1. Select a category of letter from the dropdown menu.\n"
            "2. Choose an existing contact or create a new one.\n"
            "3. Enter specific details or parameters for the letter in the text box. In general, you want to fill in specific details like a date of an accident or amount of judgement.\n"
            "4. Click 'Submit' to generate the letter.\n"
            "5. View the generated response in the 'log' folder where you will find a word document with an unique name.\n\n"
            "You can save new contacts or access pre-existing ones. Generated letters are logged automatically.\n"
            "The template word documents are in the formbase.  Put in your 'template' documents there."
        )
        QMessageBox.information(self, "Help - Legal Letter Generator", help_message)


    def initUI(self):
        self.setWindowTitle("Legal Letter Generator")
        self.setGeometry(100, 100, 1000, 800)

        layout = QVBoxLayout()

        self.category_label = QLabel("Select letter category:")
        self.category_dropdown = QComboBox()
        self.category_dropdown.addItems(["-- Select a Category --"] + get_available_categories())
        self.category_dropdown.currentIndexChanged.connect(self.on_category_selected)
        layout.addWidget(self.category_label)
        layout.addWidget(self.category_dropdown)

        self.contact_label = QLabel("Select Contact:")
        self.contact_dropdown = QComboBox()
        self.contact_dropdown.addItem("-- Select a Contact --")
        self.contact_dropdown.addItem("New Contact")
        self.contact_dropdown.setEnabled(False)
        self.contact_dropdown.currentIndexChanged.connect(self.on_contact_selected)
        layout.addWidget(self.contact_label)
        layout.addWidget(self.contact_dropdown)

        self.question_label = QLabel("Enter parameters for the legal letter:")
        self.question_text = QTextEdit()
        layout.addWidget(self.question_label)
        layout.addWidget(self.question_text)

        self.submit_button = QPushButton("Submit")
        self.submit_button.clicked.connect(self.handle_submit)
        self.submit_button.setEnabled(False)
        layout.addWidget(self.submit_button)

        self.answer_label = QLabel("Generated Response:")
        self.answer_text = QTextEdit()
        self.answer_text.setReadOnly(True)
        layout.addWidget(self.answer_label)
        layout.addWidget(self.answer_text)

        self.setLayout(layout)

        # Add the Help button
        self.help_button = QPushButton("Instructions")
        self.help_button.clicked.connect(self.show_help)
        layout.addWidget(self.help_button)

        self.setLayout(layout)


        
        
    def on_category_selected(self):
        selected_category = self.category_dropdown.currentText()
        if selected_category != "-- Select a Category --":
            document_text = read_word_document(selected_category)
            if not document_text:
                self.question_text.setPlainText("Unable to read the document for the selected category.")
                return
            suggestions = get_gpt_suggestions(document_text)
            self.question_text.setPlainText(suggestions)

            self.contact_dropdown.setEnabled(True)
            self.submit_button.setEnabled(True)
            self.populate_contacts()
        else:

            self.contact_dropdown.setEnabled(False)
            self.submit_button.setEnabled(False)


    def populate_contacts(self):
        self.contact_dropdown.clear()
        self.contact_dropdown.addItem("-- Select a Contact --")
        self.contact_dropdown.addItem("New Contact")
        for contact in self.contacts:
            self.contact_dropdown.addItem(contact['name'])
            
    def on_contact_selected(self):
        contact_index = self.contact_dropdown.currentIndex() - 2
        if self.contact_dropdown.currentText() == "New Contact":
            dialog = NewContactDialog(self)
            if dialog.exec_() == QDialog.Accepted:
                self.contacts.append(dialog.contact_info)
                self.populate_contacts()
                self.contact_dropdown.setCurrentIndex(len(self.contacts) + 1)
                self.selected_contact = dialog.contact_info
        elif contact_index >= 0:
            self.selected_contact = self.contacts[contact_index]
        else:
            self.selected_contact = None




    def handle_submit(self):
        question = self.question_text.toPlainText().strip()
        category = self.category_dropdown.currentText()

        if category == "-- Select a Category --":
            QMessageBox.warning(self, "Input Error", "Please select a letter category.")
            return

        if not self.selected_contact:
            QMessageBox.warning(self, "Input Error", "Please select a contact.")
            return

        response = ask_gpt_mini(question, category, self.selected_contact)
        self.answer_text.setPlainText(response)
        log_response_to_docx(response, category)

def main():
    # Create the application and window
    app = QApplication(sys.argv)
    window = LegalLetterApp()
    window.show()
    # Start the application's main loop
    sys.exit(app.exec_())

# Run the program only if this script is executed directly
if __name__ == "__main__":
    main()